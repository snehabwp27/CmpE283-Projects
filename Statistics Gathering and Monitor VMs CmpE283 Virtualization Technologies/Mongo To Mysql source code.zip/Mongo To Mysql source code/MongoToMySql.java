package lab4;

import java.net.UnknownHostException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.sql.*;

import com.mongodb.AggregationOutput;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.mongodb.util.JSON;

public class MongoToMySql {
	private static DB db;

	static String mongolab="mongodb://myuser:123456@ds053190.mongolab.com:53190/cmpe283team16";
	private static Connection conn;
	private static final String DRIVER = "com.mysql.jdbc.Driver";
	private static final String URL = "jdbc:mysql://127.0.0.1:3306/log";
	private static final String USERNAME = "root";
	private static final String PASSWORD = "";

	private static DB connectToMongoDb() throws UnknownHostException {
		if (db == null) {
			
			MongoClientURI uri=new MongoClientURI(mongolab);
			MongoClient client = new MongoClient( uri);
			db = client.getDB("cmpe283team16");
			//boolean auth = db.authenticate("pulkit11", "1212qwqw".toCharArray());
		}
		return db;
	}

	public static Connection connectToMySql() {
		if (conn == null) {
			try {
				Class.forName(DRIVER);
				conn = DriverManager
						.getConnection(URL, USERNAME, PASSWORD);
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return conn;
	}

	private static void archiveDataOfMongoDb() throws UnknownHostException {
		DBCollection tbl = connectToMongoDb().getCollection("data");
		Date today = new Date();
		String atblname = "archive"+today.getYear()+today.getMonth()+today.getDate();
		DBCollection atbl = connectToMongoDb().getCollection("log");
		DBCursor cur = tbl.find();
		while (cur.hasNext()) {
			atbl.insert(cur.next());
		}
		tbl.drop();
	}

	public static String getAggregateData() throws UnknownHostException {
		
		DBCollection tbl = connectToMongoDb().getCollection("log");
		//DBCursor cur =tbl.find();
		//System.out.println("cur is:" + cur);
		//String grp = "{$group:{_id:'$timestamp',avgcpu:{$avg:'$cpuusage'},avgmemory:{$avg:'$memoryusage'},vmname:{$avg:'$vmname'}}}";
		String grp = "{$group:{_id:'$vmname',avgcpu:{$avg:'$cpuusage'},avgmemory:{$avg:'$memoryusage'},avgdisk:{$avg:'$diskusage'},avgnetwork:{$avg:'$networkusage'}}}";
		
		//String grp=null;
		DBObject group = (DBObject) JSON.parse(grp);
		
		String name=(String) group.get("vmname");
		
		Timestamp date = new java.sql.Timestamp(Calendar.getInstance().getTime().getTime());
		
		System.out.println(date);
		
		AggregationOutput output = tbl.aggregate(group);
		//AggregationOutput output = null;
		DBObject dbo1 = tbl.findOne();
		String vmname = (String) dbo1.get("vmname");
		String timestamp = (String) dbo1.get("timestamp");
		int cpuusage = (int) dbo1.get("cpuusage");
		int memoryusage = (int) dbo1.get("memoryusage");
		int networkusage = (int) dbo1.get("networkusage");
		int diskusage = (int) dbo1.get("diskusage");
		System.out.println(vmname+timestamp+cpuusage+memoryusage+networkusage+diskusage);
		
		
		ArrayList<DBObject> list = (ArrayList<DBObject>) output.results();
		//ArrayList<DBObject> list = null;
		for (DBObject dbObject : list) {
			
			DBObject dbo = tbl.findOne();
			//String name = (String) dbo.get("vmname");
			System.out.println("name is"+name);
			System.out.println(dbObject);
			insertIntoMySql(dbObject,date);
			
			String s=dbObject.get("_id").toString();
			long l = Long.parseLong(s);
			//long time=(long) group.get("_id");

			Timestamp dateFormat1 = new java.sql.Timestamp(l);
			
			System.out.println("time is "+ dateFormat1);
		}
		archiveDataOfMongoDb();
		return "";
	}

	public static void insertIntoMySql(DBObject obj, Timestamp date) {
		try {
			PreparedStatement st = (PreparedStatement) connectToMySql().prepareStatement("insert into log.logtable(vnmane,cpuusage,memoryusage,diskusage,networkusage,time) values(?,?,?,?,?,?)");
			//st.setString(1, "1");
			//st.setString(2, "team12-desktop");
			st.setString(1, obj.get("_id").toString());
			st.setDouble(2, Double.parseDouble( obj.get("avgcpu").toString()));
			st.setDouble(3, Double.parseDouble( obj.get("avgmemory").toString()));
			st.setDouble(4, Double.parseDouble( obj.get("avgdisk").toString()));
			st.setDouble(5, Double.parseDouble( obj.get("avgnetwork").toString()));
			st.setTimestamp(6, date);
			//st.setDouble(6, Double.parseDouble( obj.get("avgsystem").toString()));
			st.executeUpdate();
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	static Thread t1 = new Thread(){
		public void run(){
			while(true){
			try{
			getAggregateData();
			Thread.sleep(30000);
			}catch(UnknownHostException e){
				e.printStackTrace();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			}
		}
	};

	public static void main(String[] args) throws UnknownHostException {
		t1.start();
	}
}
